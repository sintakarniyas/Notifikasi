package com.example.pushnotif;

public class User {

    public String email;
    public String token;

    public User(String email, String token){
        this.email = email;
        this.token = token;
    }

}
